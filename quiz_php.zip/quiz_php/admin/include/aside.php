<aside class="left-side sidebar-offcanvas">

                <!-- sidebar: style can be found in sidebar.less -->

                <section class="sidebar">

                    <!-- Sidebar user panel -->

                    <div class="user-panel">

                        <div class="pull-left image">

                            <img src="img/avatar3.png" class="img-circle" alt="User Image" />

                        </div>

                        <div class="pull-left info">

                            <p>Hello, Jane</p>



                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>

                        </div>

                    </div>


                    <!-- sidebar menu: : style can be found in sidebar.less -->

                    <ul class="sidebar-menu">

                        <li class="active">

                            <a href="<?php echo $siteurl;?>/index.php">

                                <i class="fa fa-dashboard"></i> <span>Dashboard</span>

                            </a>

                        </li>

                        <li>

                            <a href="<?php echo $siteurl;?>/category.php">

                                <i class="fa fa-th"></i> <span>Category</span>

                            </a>

                        </li>

                        <li>

                            <a href="<?php echo $siteurl;?>/questions.php">

                                <i class="fa fa-th"></i> <span>Questions</span>

                            </a>

                        </li>

                        <li>

                            <a href="<?php echo $siteurl;?>/users.php">

                                <i class="fa fa-th"></i> <span>Users</span>

                            </a>

                        </li>

                    </ul>

                </section>

                <!-- /.sidebar -->

            </aside>