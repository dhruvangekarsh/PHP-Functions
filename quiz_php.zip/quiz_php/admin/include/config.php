<?php 
	$con = new mysqli('localhost','ekarshpr_quizphp','H$-byAgv(Hbt','ekarshpr_quiz_php');
	define('frontpath',"http://ekarsh-projects.com/quiz_php");
	$siteurl ="http://ekarsh-projects.com/quiz_php/admin";
	function sendsmtpmail($fromname,$fromis,$tois,$messageis)
{
$unameis = "Ekarsh InfoTech";
require("class.phpmailer.php");
require("class.smtp.php");

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Host = "mail.ekarsh-projects.com";
$mail->SMTPAuth = true;
$mail->Port       = 25;
$mail->Username = "smtp@ekarsh-projects.com";
$mail->Password = "E3h%qxtE*]i}";

$mail->From = "smtp@ekarsh-projects.com";


$mail->FromName = ("$fromname");
$mail->AddAddress("$tois");

$mail->AddAddress("$fromis");


$mail->AddReplyTo("monika.gajera@ekarsh.com");

$mail->WordWrap = 50;
 
$mail->IsHTML(true);

$mail->Subject = "Inquiry";
$mail->Body    = $messageis;

if(!$mail->Send())
{
  
   echo $mail->ErrorInfo; exit;
}

return true;
}

session_start();
	
?>