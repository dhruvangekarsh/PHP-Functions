<?php
require_once('config.php');
?>

<link href="<?php echo $siteurl;?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/ionicons.min.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/morris/morris.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

<link href="<?php echo $siteurl;?>/css/AdminLTE.css" rel="stylesheet" type="text/css" />

