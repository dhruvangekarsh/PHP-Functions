<?php
	ob_start();

	require_once('../include/config.php');
	
	unset($_SESSION['admin']);
	session_destroy();
	
	header('location:'.$siteurl.'/login.php');
	
	ob_flush();
?>