<?php
require_once('../include/config.php');


if(!empty($_POST["category"])) {
	$cat_id = $_POST['category'];
	$query ="SELECT * FROM subcategory WHERE category_id = '$cat_id'";
	$results = $con->query($query);
?>
	<option value="">Select Sub Category</option>
<?php
	foreach($results as $subcategory) {
?>
	<option value="<?php echo $subcategory['sub_cat_id']; ?>"><?php echo $subcategory['subcategory']; ?></option>
<?php
	}
}
?>