<?php
	
	require_once('../include/config.php');

	$sub_cat_id = $_REQUEST['sub_cat_id'];
	$category = $_REQUEST['edit_category'];
	$subcategory = $_REQUEST['edit_sub_cat'];
	
	$update_sql = "UPDATE subcategory SET category_id='$category', subcategory='$subcategory' WHERE sub_cat_id='$sub_cat_id'";
	$update = $con->query($update_sql);
	
	$sql_select_subcat = "SELECT category.category_id, category.category,subcategory.subcategory,subcategory.sub_cat_id FROM category INNER JOIN subcategory ON category.category_id=subcategory.category_id";
		$select_sub_cat = $con->query($sql_select_subcat);
		?>
        
      
               
        <?php
		$j=1;
		while($subcat_data = $select_sub_cat->fetch_array()){
			?>
            <tr>
                <td><?php echo $j; ?></td>
                <td><?php echo $subcat_data['category']; ?></td>
                <td><?php echo $subcat_data['subcategory']; ?></td>
                 <td><a  data-toggle="modal" href="#" onClick="return editsubcategory(<?php echo $subcat_data['sub_cat_id']; ?>);" title="Edit"><i class="fa fa-edit"></i></a> &nbsp; <a href="pages/del_category.php?del_subcategory=<?php echo $subcat_data['sub_cat_id']; ?>" title="Delete"><i class="fa fa-close"></i></a></td>
            </tr>
           
                                                 
                                               
            
            
            <?php
			$j++;
		}
		?>

           
	</div>
        <script>
            $(function() {
                $("#subcategory").dataTable();
			});
		</script>
        <?php
?>