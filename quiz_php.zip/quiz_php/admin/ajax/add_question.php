<?php
	require_once('../include/config.php');

	if(isset($_REQUEST['question_table'])){
		
		$question_table = strtolower($_REQUEST['question_table'].'_quiz');	
		$question_title = $_REQUEST['question_title'];
		$question = $_REQUEST['question'];
		$ans1 = $_REQUEST['ans1'];
		$ans2 = $_REQUEST['ans2'];
		$ans3 = $_REQUEST['ans3'];
		$ans4 = $_REQUEST['ans4'];
		$right_ans = $_REQUEST['right_ans'];
		
		$sql = "INSERT INTO ".$question_table." (question_title,question,ans1,ans2,ans3,ans4,right_ans) VALUES ('$question_title','$question','$ans1','$ans2','$ans3','$ans4','$right_ans')";
		$add_question = $con->query($sql);
		
		echo "Question Added Successfully";
	}
	else{
		echo "Error";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//$add_question= $con->prepare("INSERT INTO ? (question_title,question,ans1,ans2,ans3,ans4) VALUES (?,?,?,?,?,?)");
//	$add_question->bind_param("sssssss", $question_table, $question_title, $question, $ans1, $ans2, $ans3, $ans4);
//	
//	if(isset($_REQUEST['question_name'])){
//		
//		$question_table = $_REQUEST['question_name'].'_quiz';	
//		$question_title = $_REQUEST['question_name'];
//		$question = $_REQUEST['question'];
//		$ans1 = $_REQUEST['ans1'];
//		$ans2 = $_REQUEST['ans2'];
//		$ans3 = $_REQUEST['ans3'];
//		$ans4 = $_REQUEST['ans4'];
//		
//		$add_question->execute();
//	}
//	
//	echo "New Quetion Added";
//	
//	$add_question->close();
	
	
	
	
?>






