<?php



	require_once('../include/config.php');



	$add_cat = $con->prepare("INSERT INTO category (category) VALUES (?)");

	$add_cat->bind_param("s", $cat);

	

	if(isset($_REQUEST['catname'])){

		$cat = $_REQUEST['catname'];

		$add_cat->execute();

		

		

			

			$sql_selectcat = "SELECT * FROM category";

			$select_cat = $con->query($sql_selectcat);

			

			$i = 1;

			?>

			<table class="table table-striped" id="category">

                                        <tr>

                                            <th style="width: 10px">#</th>

                                            <th>Category</th>

                                            <th style="width: 100px">Remove</th>

                                        </tr>

			<?php

			while($cat_data = $select_cat->fetch_array())

			{

				?>

				<tr>

                    <td><?php echo $i; ?></td>

                    <td><?php echo $cat_data['category'] ?></td>

                    <td><a href="category.php?del_category=<?php echo $cat_data['category_id']; ?>" title="Delete"><i class="fa fa-times" aria-hidden="true"></i></a></td>

                </tr>

                 <?php

				 $i++;

			}

		

	}

	$add_cat->close();	

	

	

	

	

	//if(isset($_REQUEST['edit_cat_text'])){

//		$updated_cat = $_REQUEST['edit_cat_text'];

//		$cat_id = $_REQUEST['edit_cat_id'];

//		$update_cat = $con->query("UPDATE category SET category='$updated_cat' WHERE category_id='$cat_id'");

//		

//		echo 'Added Successfully';	

//	}

	

	

?>