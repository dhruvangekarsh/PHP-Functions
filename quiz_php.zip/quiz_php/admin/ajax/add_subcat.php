<?php

	require_once('../include/config.php');

	$add_subcat = $con->prepare("INSERT INTO subcategory (category_id, subcategory) VALUES (?, ?)");
	$add_subcat->bind_param("ss", $cat_id, $sub_cat);
	
	if(isset($_REQUEST['cat_name'])){
		$cat_id = $_REQUEST['cat_name'];
		$sub_cat = $_REQUEST['add_sub_cat'];
		$add_subcat->execute();
		
		
		$sql_select_subcat = "SELECT category.category,subcategory.subcategory,subcategory.sub_cat_id FROM category INNER JOIN subcategory ON category.category_id=subcategory.category_id";
		$select_sub_cat = $con->query($sql_select_subcat);
		?>
        <table class="table table-striped" id="subcategory" cellspacing="0" width="100%">
        	<thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Category</th>
                    <th>Sub-Category</th>
                    <th style="width: 40px">Actione</th>
                </tr>
            </thead>
          	<tbody>
        <?php
		$j=1;
		while($subcat_data = $select_sub_cat->fetch_array()){
			?>
            <tr>
                <td><?php echo $j; ?></td>
                <td><?php echo $subcat_data['category']; ?></td>
                <td><?php echo $subcat_data['subcategory']; ?></td>
                <td><a href="" title="Edit"><i class="fa fa-edit"></i></a> &nbsp;</td>
            </tr>
            <?php
			$j++;
		}
		?>
        <script>
            $(function() {
                $("#subcategory").dataTable();
			});
		</script>
        <?php
	}
	else{
		echo 'Error!';
	}
	
	$add_subcat->close();	
?>