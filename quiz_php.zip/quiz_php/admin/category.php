
<?php  ob_start();

 require_once('include/config.php');
 
 if(isset($_REQUEST['del_category'])){
 $del_sql = "DELETE FROM category WHERE category_id=".$_REQUEST['del_category'];
		$del_cat = $con->query($del_sql);
		
			if($del_cat){
				$del_sql1 = "DELETE FROM subcategory WHERE category_id=".$_REQUEST['del_category'];
				header('location:'.$siteurl.'/category.php'); exit;
			}
			
 }
 if(isset($_REQUEST['del_subcategory'])){
		$subcat_id = $_REQUEST['del_subcategory'];
		$del_sql = "DELETE FROM subcategory WHERE sub_cat_id='$subcat_id'";
		$del_cat = $con->query($del_sql);
		header('location:'.$siteurl.'/category.php'); exit;
 }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Admin | Dashboard</title>
       
        <?php require_once('include/links.php'); ?>
    </head>
    <body class="skin-blue">
        <?php require_once('include/header.php'); ?>
        <div class="wrapper row-offcanvas row-offcanvas-left">

            <?php require_once('include/aside.php'); ?>

            <aside class="right-side">

                <section class="content-header">
                    <h1>
                        Category
                        
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </section>

                <section class="content">
				<?php 
					$sql_selectcat = "SELECT * FROM category";
					$select_cat = $con->query($sql_selectcat);
				?>
                <div class="col-md-6">
                    <div class="box">
                    			<div id="cat_alert">
                                </div>
                                <div class="box-header">
                                    <h3 class="box-title col-sm-12">Category
                                    <div class="input-group input-group-sm col-md-6 pull-right">
                                        <input type="text" id="catname" name="catname" class="form-control">
                                        <span class="input-group-btn">
                                            <button type="button" name="addcat" id="addcat" class="btn btn-info btn-flat">Add!</button>
                                        </span>
                                    </div>
                                    </h3>
                                     <div class="text-danger col-md-6 pull-right" style="display:none;" id="caterr"> Please Enter Category Name </div>
                                </div>
                                <div class="box-body no-padding">
                                    <table class="table table-striped" id="category">
                                        <tr>
                                            <th style="width: 10px">#</th>
                                            <th>Category</th>
                                            <th style="width: 100px;text-align:center;">Remove</th>
                                        </tr>
                                        <?php
											$i = 1;
											while($cat_data = $select_cat->fetch_array())
											{
												
												?>
                                                <tr>
                                                    <td><?php echo $i; ?></td>
                                                    <td><?php echo $cat_data['category'] ?></td>
                                                    <td style="text-align:center;"><a href="<?php echo $siteurl; ?>/category.php?del_category=<?php echo $cat_data['category_id']; ?>" title="Delete"><i class="fa fa-times" aria-hidden="true"></i></a></td>
                                                </tr>
                                                <?php
												$i++;
											}
										?>
                                    </table>
                                </div>
                            </div>
				</div>	
                
                <div class="col-md-6">
                	<?php
						$sql_select_subcat = "SELECT category.category_id, category.category,subcategory.subcategory,subcategory.sub_cat_id FROM category INNER JOIN subcategory ON category.category_id=subcategory.category_id";
						$select_sub_cat = $con->query($sql_select_subcat);
					?>
                    <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title col-sm-12">Sub Category
                                    <div class="input-group input-group-sm col-sm-8 pull-right">
                                        <span class="input-group-btn">
                                            <button type="button" name="addcat" class="btn btn-info btn-flat pull-right" data-toggle="modal" data-target="#addsub_cat">Add!</button>
                                        </span>
                                    </div>
                                    </h3>
                                </div>
                                <div class="box-body no-padding">
                                    
                                    <table class="table table-striped" id="subcategory" cellspacing="0" width="100%">
        								<thead>
                                        <tr>
                                            <th style="width: 10px">#</th>
                                            <th>Category</th>
                                            <th>Sub-Category</th>
                                            <th style="width: 40px">Actione</th>
                                        </tr>
                                        </thead>
                                        <tbody id="dynmc_subcat">
                                        <?php
											$j = 1;
											while($subcat_data = $select_sub_cat->fetch_array())
											{
												?>
                                                <tr>
                                                    <td><?php echo $j; ?></td>
                                                    <td><?php echo $subcat_data['category']; ?></td>
                                                    <td><?php echo $subcat_data['subcategory']; ?></td>
                                                    <td><a   href="#" onClick="return editsubcategory(<?php echo $subcat_data['sub_cat_id']; ?>);" title="Edit"><i class="fa fa-edit"></i></a> &nbsp; <a href="pages/del_category.php?del_subcategory=<?php echo $subcat_data['sub_cat_id']; ?>" title="Delete"><i class="fa fa-times" aria-hidden="true"></i></a></td>
                                                </tr>
																          
                                                <?php
												$j++;
											}
										?>
                                        </tbody>
                                        </table>
                                </div>
                                <div id="addsub_cat" class="modal fade" role="dialog">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title">Add SubCategory</h4>
                                      </div>
                                      <div class="modal-body">
                                      		<form id="add_subcat_form">
                                            	<div class="form-group">
                                                    <label>Category</label>
                                                    <select name="select_category" id="select_category" class="form-control">
                                                    <option value="">-- select Category -- </option>
                                                        <?php
															$cat = $con->query("SELECT * FROM category");
															while($category = $cat->fetch_array()){
																?><option value="<?php echo $category['category_id'];?>"><?php echo $category['category']; ?></option><?php
															}
														?>
                                                    </select>
                                                    <span id="subcaterr" style="display:none;" class="text-danger"> Please Select category </span>
                                                </div>
                                                <div class="form-group">
                                                	<lable>Sub Category</lable>
                                                    <input type="text" class="form-control" placeholder="Sub Category" name="add_sub_cat" id="add_sub_cat" />
                                                    <span id="subcatnameerr" style="display:none;" class="text-danger"> Please Enter Category name </span>
                                                </div>
                                                <div class="form-group">
                                                	<input type="button" value="Add!" id="add_subcat" name="add_subcat" class="btn btn-info btn-flat" />
                                                </div>
                                            </form>
                                      </div>
                                    </div>
                                
                                  </div>
                                </div>
                                
                            </div>
				</div>	
                </section>
            </aside>
        </div>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" style="display:none;" data-target="#edit_subcat" id="editbtn">Open Modal</button>

<div id="edit_subcat" class="modal fade" role="dialog">
                                                    <div class="modal-dialog"> 
                                                        <div class="modal-content">
                                                          <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            <h4 class="modal-title">Update Subcategory</h4>
                                                          </div>
                                                          <div class="modal-body" id="modal-bodyedit">
                                                          		<form method="post" action="ajax/edit_subcat.php" id="edit_subcat">
                                                                	<input type="hidden" name="sub_cat_id" value="<?php echo $subcat_data['sub_cat_id']; ?>"/>
                                                                	<div class="form-group">
                                                                        <label>Category</label>
                                                                        <select name="edit_category" id="edit_select_category" class="form-control">
                                                                            <?php
                                                                                $cat = $con->query("SELECT * FROM category");
                                                                                while($category = $cat->fetch_array()){
                                                                                    ?><option value="<?php echo $category['category_id'];?>" <?php if($subcat_data['category_id'] == $category['category_id']){echo 'selected';} ?>><?php echo $category['category']; ?></option><?php
                                                                                }
                                                                            ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <lable>Sub Category</lable>
                                                                        <input type="text" class="form-control" placeholder="Sub Category" name="edit_sub_cat" id="edit_sub_cat" value="<?php echo $subcat_data['subcategory'];?>" />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <input type="submit" value="Update" id="edit_subcat" name="edit_subcat" class="btn btn-info btn-flat" />
                                                                    </div>
                                                                </form> 
                                                          </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="ajaxload"> <img src="<?php echo $siteurl;?>/img/loader.gif" /></div>
        <style>
		.ajaxload {
    background: transparent none repeat scroll 0 0;
    display: none;
    height: 100%;
    left: 163px;
    position: absolute;
    text-align: center;
    top: 282px;
    width: 72%;
    z-index: 9999;
}
.ajaxload > img {
    width: 42px;
}
</style>

        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <script src="js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/AdminLTE/demo.js" type="text/javascript"></script>
        <script src="//code.jquery.com/jquery-1.12.3.js" type="text/javascript"></script>
        <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js" type="text/javascript"></script><script type="text/javascript"> </script>
		 <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js" type="text/javascript"></script><script type="text/javascript"> </script>
         <script>
            $(function() {
                $("#subcategory").dataTable();
			});
			</script>
        
   <script>
   function editsubcategory(id)
   {
	   $('.ajaxload').css({'display':'block'});
		
	   $.ajax({
		 url:'editsubcategorydetail.php',
		 type:'POST',
		 data:'id='+id,
		 success: function(data){
			 $('.ajaxload').css({'display':'none'});
			$('#modal-bodyedit').html(data); 
		 }
		   });
	   $('#editbtn').trigger('click');
	   return false;
   }
   $('#addcat').click(function(){
	   if($('#catname').val() == '')
	   {
		 $('#caterr').css({'display':'block'}); return false;   
	   }
	   else
	   {$('#caterr').css({'display':'none'});
	   }
	   $('.ajaxload').css({'display':'block'});
	   $.ajax({
		   url:'ajax/addcategory.php',
		   type:'POST',
		   data:'catname='+$('#catname').val(),
		   success:function(data){
			   $('.ajaxload').css({'display':'none'});
			   $("#category").html(data);
		   }
		   });
	   
	   });  
	   
	
	$('#add_subcat').click(function(){
	  	
	   cat_name = $('#select_category').val();
		add_sub_cat = $('#add_sub_cat').val();	
		flag=0;
		 if(cat_name == '')
	   {
		 $('#subcaterr').css({'display':'block'}); flag=1;
	   }
	   else
	   {$('#subcaterr').css({'display':'none'});
	   }
	    if(add_sub_cat == '')
	   {
		 $('#subcatnameerr').css({'display':'block'}); flag=1;
	   }
	   else
	   {$('#subcatnameerr').css({'display':'none'});
	   }
	   	if(flag ==1){ return false; }
		$('.ajaxload').css({'display':'block'});
		$.ajax({
			   type: "POST",
			   url: "ajax/add_subcat.php",
			   data: {'cat_name':cat_name,'add_sub_cat':add_sub_cat},
			   success: function(data)
			   { 
			     $('.ajaxload').css({'display':'none'});
				   $("#subcategory").html(data);
			   }
			 });
		$(".close").trigger("click")	 
	});
   </script>
   
<script src="http://malsup.github.com/jquery.form.js"></script> 
<script> 
       
        $(document).ready(function() { 
       
	   $('#edit_subcat').click(function() { 
	   
	   flag=0;
		 if($('#edit_select_category').val()== '')
	   {
		 $('#editcaterr').css({'display':'block'}); flag=1;
	   }
	   else
	   {$('#editcaterr').css({'display':'none'});
	   }
	    if($('#edit_sub_cat').val() == '')
	   {
		 $('#editcatnameerr').css({'display':'block'}); flag=1;
	   }
	   else
	   {$('#editcatnameerr').css({'display':'none'});
	   }
	   	if(flag ==1){ return false; }
	   });
            $('#edit_subcat').ajaxForm(function(data) { 
			  
			
		
                $("#dynmc_subcat").html(data);
				$(".close").trigger('click');
            }); 
        }); 
</script>   
   
    </body>
</html><br>


<?php ob_flush(); ?>
