<?php
	require_once('../include/config.php');
	
	if($_REQUEST['q_id']){
		$question_id = $_REQUEST['q_id'];
		$q = $con->query("DELETE FROM questions WHERE question_id='$question_id'");
		header('location:../questions.php');		
	}
?>