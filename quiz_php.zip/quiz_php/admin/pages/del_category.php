<?php 

	ob_start();

	require_once('../include/config.php');



	if(isset($_REQUEST['del_category'])){

		$cat_id = $_REQUEST['del_category'];

		$del_sql = "DELETE FROM category WHERE category_id='$cat_id'";

		$del_cat = $con->query($del_sql);

		

			if($del_cat){

				$del_sql1 = "DELETE FROM subcategory WHERE category_id='$cat_id'";

				header('location:'.$siteurl.'/category.php'); exit;

			}else{

				echo "Error!";

			}

		

		header('location:'.$siteurl.'/category.php'); exit;

			

	}

	

	

	if(isset($_REQUEST['del_subcategory'])){

		$subcat_id = $_REQUEST['del_subcategory'];

		$del_sql = "DELETE FROM subcategory WHERE sub_cat_id='$subcat_id'";

		$del_cat = $con->query($del_sql);

		

		//header('location:'.$siteurl.'/category.php'); exit;
		echo'<script>window.location="../category.php";</script>';
		

	}

	

	ob_flush();

?>