<?php 
 ob_start();
 require_once('../include/config.php');
 $q_id = $_REQUEST['q_id'];
 $q = $con->query("SELECT * FROM questions WHERE question_id='$q_id'");
 $q_data = $q->fetch_array();
?>
 <?php
			
				
				

				if(isset($_REQUEST['update_q'])){

					$q_title = $_REQUEST['q_title'];

					$q = $_REQUEST['q'];

					$ans1 = $_REQUEST['a1'];

					$ans2 = $_REQUEST['a2'];

					$ans3 = $_REQUEST['a3'];

					$ans4 = $_REQUEST['a4'];

					$ans_right = $_REQUEST['ar'];

					$category = $_REQUEST['cate'];
					
					$subcategory = $_REQUEST['sub_cat'];

					$update_sql = "UPDATE questions SET question_title='$q_title',question='$q',ans1='$ans1',ans2='$ans2',ans3='$ans3',ans4='$ans4',ans_right='$ans_right',category='$category',subcategory='$subcategory' WHERE question_id='$q_id'";

					

					$upd = $con->query($update_sql);

					header('location:'.$siteurl.'/questions.php'); exit;
					

				}

			?>
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Admin | Edit Questions</title>
		<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <?php require_once("../include/links.php");?>
</head>

<body class="skin-blue">

	<?php //require_once('../include/header.php'); ?>
<div class="wrapper row-offcanvas row-offcanvas-left"> 

  <!-- Left side column. contains the logo and sidebar -->

	<?php require_once("../include/aside.php");?>

 

  <aside class="right-side">

    <section class="content-header">

      <h1>Update Question</h1>

      <ol class="breadcrumb">

        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>

        <li class="active">Update Question</li>

      </ol>

    </section>

    <h4>&nbsp;</h4>

  			<div class="col-md-12">

            

        	<form method="post">

            	<div class="form-group">

                	<label>Question Title</label>

               	  <input class="form-control" type="text" name="q_title" value="<?php echo $q_data['question_title'];?>" required/>

                </div>

                <div class="form-group">

                	<label>Question</label>

               	  <input class="form-control" type="text" name="q" value="<?php echo $q_data['question'];?>" required/>

                </div>

                <div class="form-group">

                	<label>Answer 1</label>

               	  <input class="form-control" type="text" name="a1" value="<?php echo $q_data['ans1'];?>" required/>

                </div>

                <div class="form-group">

                	<label>Answer 2</label>

               	  <input class="form-control" type="text" name="a2" value="<?php echo $q_data['ans2'];?>" required/>

                </div>

                <div class="form-group">

                	<label>Answer 3</label>

               	  <input class="form-control" type="text" name="a3" value="<?php echo $q_data['ans3'];?>" required/>

                </div>

                <div class="form-group">

                	<label>Answer 4</label>

               	  <input class="form-control" type="text" name="a4" value="<?php echo $q_data['ans4'];?>" required/>

                </div>

                <div class="form-group">

                	<label>Right Answer</label>

               	  	<select class="form-control" name="ar" required>

                    	<option disabled value="">Select Right Answer</option>

                    	<option value="1" <?php if($q_data['ans_right']==1){echo "selected";}?>>Answer 1</option>

                        <option value="2" <?php if($q_data['ans_right']==2){echo "selected";}?>>Answer 2</option>

                        <option value="3" <?php if($q_data['ans_right']==3){echo "selected";}?>>Answer 3</option>

                        <option value="4" <?php if($q_data['ans_right']==4){echo "selected";}?>>Answer 4</option>

                    </select>

                </div>

               
               <div class="form-group">

                	<label>Category</label>

               	  	<select class="form-control" name="cate" required>

                    	<option disabled value="">Select Category</option>
						
                        <?php
						$cat1 = $con->query("SELECT * FROM category");
						while($cat_data = $cat1->fetch_array()){
							?>
                            <option value="<?php echo $cat_data['category_id'];?>"<?php if($q_data['category']==$cat_data['category_id']){echo "selected";} ?>><?php echo $cat_data['category'];?></option>
                            <?php
						}
						?>	

                    </select>

                </div>
                
                
                <div class="form-group">

                  <label>Sub Category</label>

               	  <select class="form-control" name="sub_cat" id="sub-cat-list" required>
                  		<?php
						$subcat1 = $con->query("SELECT * FROM subcategory");
						while($subcat_data = $subcat1->fetch_array()){
							?>
                            <option value="<?php echo $subcat_data['sub_cat_id'];?>"<?php if($q_data['subcategory']==$subcat_data['sub_cat_id']){echo "selected";} ?>><?php echo $subcat_data['subcategory'];?></option>
                            <?php
						}
						?>
                  </select>

                </div>
               
               

                <div class="form-group">

                	<input type="submit" name="update_q" value="Update Question" class="btn btn-flat btn-info" />

                </div>

            </form>

            

           

            

            </div>

         </aside>

         </div>   

            

<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>

        <!-- jQuery UI 1.10.3 -->

        <script src="<?php echo $siteurl;?>/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>

        <!-- Bootstrap -->

        <script src="<?php echo $siteurl;?>/js/bootstrap.min.js" type="text/javascript"></script>        

         <script src="//code.jquery.com/jquery-1.12.3.js" type="text/javascript"></script>

        <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js" type="text/javascript"></script><script type="text/javascript"> </script>

		 <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js" type="text/javascript"></script><script type="text/javascript"> </script>

         <script>

            $(function() {

                $("#subcategory").dataTable();

			});

			</script>  

        

</body>

</html>  
<?php ob_flush(); ?>