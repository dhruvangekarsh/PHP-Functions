<?php
	
	require_once('../include/config.php');	
	
	if(isset($_REQUEST['add_q'])){
		$q_title = $_REQUEST['q_title'];
		$q = $_REQUEST['q'];
		$a1 = $_REQUEST['a1'];
		$a2 = $_REQUEST['a2'];
		$a3 = $_REQUEST['a3'];
		$a4 = $_REQUEST['a4'];
		$ar = $_REQUEST['ar'];
		$cat = $_REQUEST['quiz_cat'];
		$subcat = $_REQUEST['quiz_sub_cat'];
		
		$add_questions = $con->query("INSERT INTO questions VALUES('','$q_title','$q','$a1','$a2','$a3','$a4','$ar','$cat','$subcat')");
		
		header("location:../questions.php");
		
	}
?>