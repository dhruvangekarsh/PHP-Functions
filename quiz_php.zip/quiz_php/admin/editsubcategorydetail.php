
<?php  include('include/config.php'); 
						$sql_select_subcat = "SELECT category.category_id, category.category,subcategory.subcategory,subcategory.sub_cat_id FROM category INNER JOIN subcategory ON category.category_id=subcategory.category_id where subcategory.sub_cat_id=".$_POST['id'];
						$select_sub_cat = $con->query($sql_select_subcat);
						$subcat_data=$select_sub_cat->fetch_array();
					?>
<form method="post" action="ajax/edit_subcat.php" id="edit_subcat">
                                                                	<input type="hidden" name="sub_cat_id" value="<?php echo $subcat_data['sub_cat_id']; ?>"/>
                                                                	<div class="form-group">
                                                                        <label>Category</label>
                                                                        <select name="edit_category" id="edit_select_category" class="form-control">
                                                                            <?php
                                                                                $cat = $con->query("SELECT * FROM category");
                                                                                while($category = $cat->fetch_array()){
                                                                                    ?><option value="<?php echo $category['category_id'];?>" <?php if($subcat_data['category_id'] == $category['category_id']){echo 'selected';} ?>><?php echo $category['category']; ?></option><?php
                                                                                }
                                                                            ?>
                                                                        </select>
                                                                        <span style="display:none;" class="text-danger" id="editcaterr"> Please select category </span>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <lable>Sub Category</lable>
                                                                        <input type="text" class="form-control" placeholder="Sub Category" name="edit_sub_cat" id="edit_sub_cat" value="<?php echo $subcat_data['subcategory'];?>" />
                                                                        <span style="display:none;" class="text-danger" id="editcatnameerr"> Please enter category name </span>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <input type="submit" value="Edit" id="edit_subcat" name="edit_subcat" class="btn btn-info btn-flat" />
                                                                    </div>
                                                                </form>