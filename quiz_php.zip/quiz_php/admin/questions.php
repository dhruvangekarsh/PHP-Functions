<?php 

 require_once('include/config.php');
 
 if($_SESSION['admin']){

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Admin | Dashboard</title>

<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>

       

        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">

        <!-- Ionicons -->

        <link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />

        <!-- Morris chart -->

        <link href="css/morris/morris.css" rel="stylesheet" type="text/css" />

        <!-- jvectormap -->

        <link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />

        <!-- Date Picker -->

        <link href="css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />

        <!-- Data table -->

        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

         <!-- bootstrap 3.0.2 -->

        <link href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" />

        <!-- Daterange picker -->

        <link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />

        <!-- bootstrap wysihtml5 - text editor -->

        <link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

        <!-- Theme style -->

        <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />

</head>

<body class="skin-blue">

<?php require_once('include/header.php'); ?>

<div class="wrapper row-offcanvas row-offcanvas-left"> 

  <!-- Left side column. contains the logo and sidebar -->

  <?php require_once('include/aside.php'); ?>

  <aside class="right-side">

    <section class="content-header">

      <h1>Add Quiz</h1>

      <ol class="breadcrumb">

        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>

        <li class="active">Add Quiz</li>

      </ol>

    </section>

    <h3 class="box-title col-sm-12">

      <div class="input-group input-group-sm pull-left"> <span class="input-group-btn"> <a data-toggle="modal" data-target="#questions" class="btn btn-primary btn-flat">Add Questions</a> </span> </div>

    </h3>

    



	<table class="table table-striped" id="subcategory" cellspacing="0" width="100%">

        <thead>

            <tr>

                <th style="width: 10px">#</th>

                <th>Question Title</th>

                <th>Question</th>

                <th>Answer 1</th>

                <th>Answer 2</th>

                <th>Answer 3</th>

                <th>Answer 4</th>

                <th>Category</th>

                <th>Sub Category</th>

                <th style="width: 40px">Action</th>

            </tr>

        </thead>

        <tbody>

        	<?php

				$i=1;

				$question_sql = "SELECT q.question_id,q.question_title,q.question,q.ans1,q.ans2,q.ans3,q.ans4,q.ans_right,q.category,q.subcategory,c.category,sb.subcategory FROM questions q INNER JOIN category c ON q.category=c.category_id INNER JOIN subcategory sb ON q.subcategory=sb.sub_cat_id";

				$questions = $con->query($question_sql);

				while($qs = $questions->fetch_array()){

					?>

                    <tr>

                    	<td><?php echo $i;?></td>

                        <td><?php echo $qs['question_title']?></td>

                        <td><?php echo $qs['question']?></td>

                        <td><?php echo strtr($qs['ans1'],Array("<"=>"&lt;","&"=>"&amp;"));?></td>

                        <td><?php echo strtr($qs['ans2'],Array("<"=>"&lt;","&"=>"&amp;"));?></td>

                        <td><?php echo strtr($qs['ans3'],Array("<"=>"&lt;","&"=>"&amp;"));?></td>

                        <td><?php echo strtr($qs['ans4'],Array("<"=>"&lt;","&"=>"&amp;"));?></td>

                        <td><?php echo $qs['category']?></td>

                        <td><?php echo $qs['subcategory']?></td>

                        <td><a href="pages/edit_questions.php?q_id=<?php echo $qs['question_id'];?>"><i class="fa fa-edit"></i></a> &nbsp; <a href="pages/del_question.php?q_id=<?php echo $qs['question_id'];?>"><i class="fa fa-close"></i></a></td>

                    </tr>

                    <?php

					$i++;

				}

			?>

        </tbody>

    </table>

                                            	



    </aside>

  

<!-- Add Question Modal -->



<div id="questions" class="modal fade" role="dialog">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>

        <h4 class="modal-title">Modal Header</h4>

      </div>

      <div class="modal-body">

        	<form method="post" action="pages/add_question.php">

            	<div class="form-group">

                	<label>Question Title</label>

               	  <input class="form-control" type="text" name="q_title" />

                </div>

                <div class="form-group">

                	<label>Question</label>

               	  <input class="form-control" type="text" name="q" />

                </div>

                <div class="form-group">

                	<label>Answer 1</label>

               	  <input class="form-control" type="text" name="a1" />

                </div>

                <div class="form-group">

                	<label>Answer 2</label>

               	  <input class="form-control" type="text" name="a2" />

                </div>

                <div class="form-group">

                	<label>Answer 3</label>

               	  <input class="form-control" type="text" name="a3" />

                </div>

                <div class="form-group">

                	<label>Answer 4</label>

               	  <input class="form-control" type="text" name="a4" />

                </div>

                <div class="form-group">

                	<label>Right Answer</label>

               	  	<select class="form-control" name="ar">

                    	<option selected disabled>Select Right Answer</option>

                    	<option value="1">Answer 1</option>

                        <option value="2">Answer 2</option>

                        <option value="3">Answer 3</option>

                        <option value="4">Answer 4</option>

                    </select>

                </div>

                <div class="form-group">

                	<label>Category</label>

                	<select class="form-control" name="quiz_cat" onChange="getSubCat(this.value);">

                    	<option selected disabled>Select Category</option>

                    <?php

						$sql_selectcat = "SELECT * FROM category";

						$select_cat = $con->query($sql_selectcat);

						while($cat_data = $select_cat->fetch_array())

						{

							?>

                            <option value="<?php echo $cat_data['category_id']; ?>"><?php echo $cat_data['category']; ?></option>

                            <?php

						}

					?>    

                    </select>

                </div>

                <div class="form-group">

                  <label>Sub Category</label>

               	  <select class="form-control" name="quiz_sub_cat" id="sub-cat-list">

                    </select>

                </div>

                <div class="form-group">

                	<input type="submit" name="add_q" value="Add Question" class="btn btn-flat btn-info" />

                </div>

            </form>

      </div>

    </div>

  </div>

</div>



<!-- Add Question Modal end-->

  

  

</div>

<!-- jQuery UI 1.10.3 --> 

<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>

        <!-- jQuery UI 1.10.3 -->

        <script src="js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>

        <!-- Bootstrap -->

        <script src="js/bootstrap.min.js" type="text/javascript"></script>        

         <script src="//code.jquery.com/jquery-1.12.3.js" type="text/javascript"></script>

        <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js" type="text/javascript"></script><script type="text/javascript"> </script>

		 <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js" type="text/javascript"></script><script type="text/javascript"> </script>

         <script>

            $(function() {

                $("#subcategory").dataTable();

			});

			</script>  

<script>

	function getSubCat(val) {

		$.ajax({

		type: "POST",

		url: "ajax/get_subcat.php",

		data:'category='+val,

		success: function(data){

			$("#sub-cat-list").html(data);

		}

		});

	}

</script>             

</body>

</html>  
<?php
 }
 else{
	 header('location:'.$siteurl.'/login.php');
 }
?>