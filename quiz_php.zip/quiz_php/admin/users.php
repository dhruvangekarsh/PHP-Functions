<?php 

 require_once('include/config.php');
	if(isset($_SESSION['admin']))
	{
?>

<!DOCTYPE html>

<html>

    <head>

        <meta charset="UTF-8">

        <title>Admin | Dashboard</title>

       

        <?php require_once('include/links.php'); ?>

    </head>

    <body class="skin-blue">

        <?php require_once('include/header.php'); ?>

        <div class="wrapper row-offcanvas row-offcanvas-left">



            <?php require_once('include/aside.php'); ?>



            <aside class="right-side">

				<section class="content-header">

                    <h1>

                        Users

                    </h1>

                    <ol class="breadcrumb">

                        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>

                        <li class="active">Users</li>

                    </ol>

                </section>

                

                <section class="content">

                    <div class="row">

                        <div class="col-xs-12">

                            <div class="box">

                                <div class="box-header">

                                    <h3 class="box-title">User Data</h3>

                                </div>

                                <div class="box-body table-responsive">

                                    

                                    <table class="table table-striped" id="users" cellspacing="0" width="100%">

                                        <thead>

                                            <tr>

                                                <th style="width: 10px">#</th>

                                                <th>Name</th>

                                                <th>Email</th>

                                                <th>Result</th>
                                                
                                                <th style="text-align:center;">Action</th>

                                            </tr>

                                        </thead>

                                        <tbody>

                                            <?php

                                                $i=1;

                                                $user_sql = "SELECT * FROM users";

                                                $users = $con->query($user_sql);

                                                while($user = $users->fetch_array()){

                                                    ?>

                                                    <tr>

                                                        <td><?php echo $i;?></td>

                                                        <td><?php echo $user['name']?></td>

                                                        <td><?php echo $user['email']?></td>

                                                        <td><?php echo $user['result']?></td>
                                                        
                                                        <td style="text-align:center;"><a href="users.php?u_id=<?php echo $user['user_id'];?>"><i class="fa fa-times" aria-hidden="true"></i></a></td>

                                                    </tr>

                                                    <?php

                                                    $i++;

                                                }

                                            ?>

                                        </tbody>

                                        <tfoot>

                                            <tr>

                                                <th style="width: 10px">#</th>

                                                <th>Name</th>

                                                <th>Email</th>

                                                <th>Result</th>
                                                
                                                <th style="text-align:center">Action</th>

                                            </tr>

                                        </tfoot>

                                    </table>

    

                                </div>

                            </div>

                        </div>

                    </div>



                </section>

                

            </aside>

        </div>





        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>

        <script src="js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>

        <script src="js/bootstrap.min.js" type="text/javascript"></script>

        <script src="js/AdminLTE/demo.js" type="text/javascript"></script>

        <script src="//code.jquery.com/jquery-1.12.3.js" type="text/javascript"></script>

        <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js" type="text/javascript"></script>

		 <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js" type="text/javascript"></script>

         <script>

            $(function() {

                $("#users").dataTable();

			});

			</script>

   

    </body>

</html>
<?php

	if($_REQUEST['u_id'])
	{
		$user_id = $_REQUEST['u_id'];
		
		$del_user = $con->query("DELETE FROM users WHERE user_id='$user_id'");
		
		header("users.php");
	}


	}
	else{
		header('location:'.$siteurl.'/login.php');
	}
?>