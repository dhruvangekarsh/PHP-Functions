<?php
	require_once('include/config.php');
	if(isset($_SESSION['admin']))
	{
?>
<!DOCTYPE html>

<html>

    <head>

        <meta charset="UTF-8">

        <title>AdminLTE | Dashboard</title>

        <?php require_once('include/links.php'); ?>

    </head>

    <body class="skin-blue">

        <?php require_once('include/header.php'); ?>

        <div class="wrapper row-offcanvas row-offcanvas-left">

          

            <?php require_once('include/aside.php'); ?>



			<?php				

				$cat = $con->query("SELECT * FROM category");

				$num_cat = $cat->num_rows;

				

				$subcat = $con->query("SELECT * FROM subcategory");

				$num_subcat = $subcat->num_rows;

				

				$ques = $con->query("SELECT * FROM questions");

				$num_question = $ques->num_rows;

				

			?>



            <aside class="right-side">

            

                <section class="content-header">

                    <h1>

                        Dashboard

                        <small>Control panel</small>

                    </h1>

                    <ol class="breadcrumb">

                        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

                        <li class="active">Dashboard</li>

                    </ol>

                </section>



                <section class="content">



                    <div class="row">

                        <div class="col-lg-3 col-xs-6">



                            <div class="small-box bg-aqua">

                                <div class="inner">

                                	<center>

                                    <h3>

                                        <?php echo $num_cat; ?>(<?php echo $num_subcat; ?>)

                                    </h3>

                                    <p>

                                        Category(Sub Category)

                                    </p>

                                    </center>

                                </div>

                                <a href="category.php" class="small-box-footer">

                                    More info <i class="fa fa-arrow-circle-right"></i>

                                </a>

                            </div>

                        </div>

                        <div class="col-lg-3 col-xs-6">



                            <div class="small-box bg-green">

                                <div class="inner">

                                	<center>

                                    <h3>

                                    	<?php echo $num_question; ?> 

                                    </h3>

                                    <p>

                                        Questions

                                    </p>

                                    </center>

                                </div>

                                <a href="questions.php" class="small-box-footer">

                                    More info <i class="fa fa-arrow-circle-right"></i>

                                </a>

                            </div>

                        </div>

                    </div>



                </section>

            </aside>

        </div>

		<?php require_once('include/scripts.php'); ?>

    </body>

</html>
<?php
	}
	else{
		header('location:'.$siteurl.'/login.php');
	}
?>