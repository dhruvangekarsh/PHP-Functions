<!-- Footer section -->
<footer>
	<div class="container">
		<div class="row">

              <div class="wow fadeInUp col-md-4 col-sm-4" data-wow-delay="0.3s">
                <h3>About the house</h3>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod 
                	tincidunt ut laoreet. Dolore magna aliquam erat volutpat ipsum.</p>
              </div>  
        
              <div class="wow fadeInUp col-md-4 col-sm-4" data-wow-delay="0.6s">
                <h3>Contact Detail</h3>
                <p>437, Maruti Plaza,Opp Vijay Park Brts bus stand,Krishnanagar,Ahmedabad.</p>
                <a href="call: +91 8980506777">(+) 8 9 8 0 5 0 6 7 7 7</a>
                <a href="mailto:info@ekarsh.com">info@ekarsh.com</a>
              </div> 
        
              <div class="wow fadeInUp col-md-4 col-sm-4" data-wow-delay="0.9s">
                <h3>Opening Hours</h3>
                <strong>Monday - Firday</strong>
                <p>11:00 AM - 10:00 PM</p>
                <strong>Saturday - Sunday</strong>
                <p>10:00 AM - 09:00 PM</p>
              </div> 

		</div>
	</div>
</footer>

<!-- Copyright section -->
<section id="copyright">
  <div class="container">
    <div class="row">

      <div class="col-md-8 col-sm-8 col-xs-8">
        <p>Copyright © 2016 Quiz - Designed by <a class="designed-by" href="#" target="_blank">eKarsh InfoTech</a></p>
      </div>  

      <div class="col-md-4 col-sm-4 text-right">
        <a href="#home" class="fa fa-angle-up smoothScroll gototop"></a>
      </div>

    </div>
  </div>
</section>