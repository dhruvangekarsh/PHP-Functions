<?php

	require_once('admin/include/config.php');
	
	if($_REQUEST['subcat'])
	{
		
		$subcat = $_REQUEST['subcat'];
		$quizer_name = $_REQUEST['quizer_name'];
		$quizer_email = $_REQUEST['quizer_email'];
			
		$que = $con->query("SELECT * FROM questions WHERE subcategory='$subcat'");
		$rowcount= $que->num_rows;
		
		for($i=1;$i<=$rowcount;$i++){
			${"que".$i} = $_REQUEST['que'.$i]."<br>";			
		}
		
		
		for($j=1;$j<=$rowcount;$j++){
			$ans_data = $que->fetch_array();	
			${"ans".$j} = $ans_data['ans_right']."<br>";
		}
		
		
		$sum = 0;
		
		for($c=1;$c<=$rowcount;$c++){
			
			if(${"que".$c} == ${"ans".$c})
			{
				$sum++;
			}
			
		}
		
		if($sum>5){
			echo "<style>.result{color:green;}</style>";
		}else{
			echo "<style>.result{color:red;}</style>";
		}
		
		if(!$que1 == FALSE){
			echo "<p class='result'>Your Result is : ".$sum." out of ".($i - 1)."</p>";
		}else{
			echo "Plz Select Any Answer";
		}
	
	
		$data = $con->query("INSERT INTO users(name,email,result)VALUES('$quizer_name','$quizer_email','$sum')");
	
	}
?>