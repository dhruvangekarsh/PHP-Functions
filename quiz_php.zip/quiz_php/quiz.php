<?php
	require_once('admin/include/config.php');
	
	if($_REQUEST['subcat_id']){
		
		$id = $_REQUEST['subcat_id'];
		
		$get_subcat_sql = $con->query("SELECT subcategory FROM subcategory WHERE sub_cat_id='$id'");
		$get_subcat = $get_subcat_sql->fetch_array();
		
		$get_question = $con->query("SELECT * FROM questions WHERE subcategory='$id'");
		$num_question = $get_question->num_rows;
		
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Steak House - Free HTML CSS Template</title>

  	<meta charset="utf-8">
	<link rel="stylesheet" href="css/bootstrap.min.css">
  	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
  	<link rel="stylesheet" href="css/nivo-lightbox.css">
  	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
  	<link rel="stylesheet" href="css/hover-min.css">
  	<link rel="stylesheet" href="css/flexslider.css">
	<link rel="stylesheet" href="css/style.css">
     <link  href="css/bootstrap.min.css" rel="stylesheet"/>
    <link href="css/prettify.css" rel="stylesheet">
  	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
  	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600' rel='stylesheet' type='text/css'>
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">


<div class="preloader">
	<div class="sk-spinner sk-spinner-pulse"></div>
</div>



<?php require_once('include/nav.php'); ?>

<section id="team" class="parallax-section">
  <div class="container">
    <div class="row">
      <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
         <div class="wow fadeInUp section-title" data-wow-delay="0.3s">
            <h2><?php echo $get_subcat['subcategory'];?> Quiz</h2>
            <h4></h4>
            
        </div>
      </div>
      <div class="clearfix"></div>
      
      <div class="col-md-12 col-sm-12 wow fadeInUp">
      		<section id="wizard">
				<div id="rootwizard">
                	<div id="bar" class="progress">
                      <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>
                    </div>
					<div class="navbar">
					  <div class="navbar-inner">
					    <div class="container">
                        <ul>
                        	<?php
								for($i=1;$i<=$num_question;$i++){
									?>
                                    <li><a href="#tab<?php echo $i;?>" data-toggle="tab"><?php echo $i;?></a></li>
                                    <?php
								}
							?>
                        </ul>
					 </div>
					  </div>
					</div>
                    <style>
						.card{float:left;width:100%;color:#000;background-color:#FFF;box-shadow:5px 5px 10px #CCC; border:none;box-sizing:border-box;}
						.question_title{font-size:20px;padding:20px 20px 0;text-align:left;}
						.col4{width:100%;float:left;margin:8px 20px;text-align:left;}
						.ans{float:left;width:100%; padding:10px 0; font-size:16px;}
						.wizard{padding-top:20px; clear:both;}
						.form{border:1px solid #ccc; padding:20px;margin-bottom:20px;}
						.previous a,.next a{cursor:pointer !important;}
						.user_data{width:100%; margin:0 auto;}
						#result{width:100%;text-align:center; font-weight:bold;}
					</style>
                    <form action="result.php" method="post" id="anssheet">
                    <input type="hidden" name="subcat" value="<?php echo $id;?>">
					<div class="tab-content">
                    <?php
						$j=1;
						while($q_data = $get_question->fetch_array()){
							?>
                            <div class="tab-pane" id="tab<?php echo $j;?>">
								<div class="card">
                                	<div class="question_title">Question : <?php echo $j." &nbsp; ".$q_data['question'];?></div>
                                    
                                    <div class="ans">
                                    	<div class="col4">
                                            <input type="radio" name="que<?php echo $j;?>" value="1" required/> &nbsp;<?php echo strtr($q_data['ans1'],Array("<"=>"&lt;","&"=>"&amp;"));?></pre>
                                        </div>
                                        <div class="col4">
                                            <input type="radio" name="que<?php echo $j;?>" value="2" required/> &nbsp;<?php echo strtr($q_data['ans2'],Array("<"=>"&lt;","&"=>"&amp;"));?></pre>
                                        </div>
                                        <div class="col4">
                                            <input type="radio" name="que<?php echo $j;?>" value="3" required/> &nbsp;<?php echo strtr($q_data['ans3'],Array("<"=>"&lt;","&"=>"&amp;"));?></pre>
                                        </div>
                                        <div class="col4">
                                            <input type="radio" name="que<?php echo $j;?>" value="4" required/> &nbsp;<?php echo strtr($q_data['ans4'],Array("<"=>"&lt;","&"=>"&amp;"));?></pre>
                                        </div>
                                    </div>
                                    
                                    
                                    <?php
										if($num_question == $j){
											?>
                                            <div id="result"></div>
                                            <div class="col-md-4 col-md-offset-4 form">
                                                <div class="form-group">
                                                    <input type="text" name="quizer_name" placeholder="Name" class="form-control" required/>
                                                </div>
                                                <div class="form-group">
                                                    <input type="email" name="quizer_email" placeholder="Email" class="form-control" required/>
                                                </div>
                                                <div class="form-group">
                                                    <input type="submit" name="submit" id="anssheet" value="GET Result!" class="btn btn-primary"/>
                                                    <a href="category.php" class="btn btn-primary"/>Restart Quiz!</a>
                                                </div>
                                            </div>
                                            <?php
										}
										else{
										}
									?>
                                    
                                </div>
                            </div>
                            <?php
							$j++;
						}
					?>
						<ul class="pager wizard">
							<li class="previous first" style="display:none;"><a href="#">First</a></li>
							<li class="previous"><a >Previous</a></li>
							<li class="next last" style="display:none;"><a href="#">Last</a></li>
						  	<li class="next"><a >Next</a></li>
						</ul>
					</div>
                    </form>
				</div>



			</section>     	 
      </div>
      
    </div>
  </div>
</section>

<?php require_once('include/footer.php'); ?>

<!-- javscript js -->
<script src="js/jquery.js" type="application/javascript"></script>
<script src="js/bootstrap.min.js" type="application/javascript"></script>

<script src="js/jquery.magnific-popup.min.js" type="application/javascript"></script>

<script src="js/jquery.sticky.js" type="application/javascript"></script>
<script src="js/jquery.backstretch.min.js" type="application/javascript"></script>

<script src="js/isotope.js" type="application/javascript"></script>
<script src="js/imagesloaded.min.js" type="application/javascript"></script>
<script src="js/nivo-lightbox.min.js" type="application/javascript"></script>

<script src="js/jquery.flexslider-min.js" type="application/javascript"></script>

<script src="js/jquery.parallax.js" type="application/javascript"></script>
<script src="js/smoothscroll.js" type="application/javascript"></script>
<script src="js/wow.min.js" type="application/javascript"></script>

<script src="js/custom.js" type="application/javascript"></script>



	<script src="js/jquery.bootstrap.wizard.js" type="application/javascript"></script>
	<script src="js/prettify.js" type="application/javascript"></script>
	<script>
	$(document).ready(function() {
	  	$('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
			var $total = navigation.find('li').length;
			var $current = index+1;
			var $percent = ($current/$total) * 100;
			$('#rootwizard .progress-bar').css({width:$percent+'%'});
		}});
		window.prettyPrint && prettyPrint()
	});
	</script>
    
    
    
<script src="http://malsup.github.com/jquery.form.js"></script> 

		<script> 
       
			$(document).ready(function() { 
		   
				$('#anssheet').ajaxForm(function(data) { 
					$("#result").html(data);
				}); 
			}); 
		</script>
    

</body>
</html>
<?php
	}
	else{
		header('location:index.php');
	}
?>