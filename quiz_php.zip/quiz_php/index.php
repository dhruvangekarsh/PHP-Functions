<?php
	require_once('admin/include/config.php');
	
	$cat_sql = $con->query("SELECT * FROM category");
	
	if($_POST['contactmail'])
	{
		sendsmtpmail($_POST['name'],$_POST['email'],"test.ekarsh@gmail.com",$_POST['message']);
		$msg="mail Send successfully";
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Online Quiz</title>

  	<meta charset="utf-8">
	<link rel="stylesheet" href="css/bootstrap.min.css">
  	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
  
  	<link rel="stylesheet" href="css/hover-min.css">
  	
	<link rel="stylesheet" href="css/style.css">
  	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
  	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600' rel='stylesheet' type='text/css'>
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">



<section id="home" style="background-image:url('<?php echo frontpath;?>/images/slide-img1.jpg');" class="parallax-section">
  <div class="gradient-overlay"></div>
    <div class="container">
      <div class="row">

          <div class="col-md-offset-2 col-md-8 col-sm-12">
              <h1 class="wow fadeInUp" data-wow-delay="0.6s">Quiz</h1>
              <p class="wow fadeInUp" data-wow-delay="1.0s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet. Dolore magna aliquam erat volutpat.</p>
              <a href="#feature" class="wow fadeInUp btn btn-default hvr-bounce-to-top smoothScroll" data-wow-delay="1.3s">Start Now</a>
          </div>

      </div>
    </div>
</section>

<?php require_once('include/nav.php'); ?>

<!-- Feature section -->
<section id="feature" class="parallax-section">
  <div class="container">
    <div class="row">

      <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
          <div class="wow fadeInUp section-title" data-wow-delay="0.6s">
            <h2>Why Choose Us?</h2>
            <h4>Steak House HTML CSS Template</h4>
          </div>
      </div>

      <div class="clearfix"></div>

      <div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
        <div class="feature-thumb">
          <div class="feature-icon">
             <span><i class="fa fa-cutlery"></i></span>
          </div>
          <h3>No Registration</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus.</p>
        </div>
      </div>

      <div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.6s">
        <div class="feature-thumb">
          <div class="feature-icon">
            <span><i class="fa fa-coffee"></i></span>
          </div>
          <h3>Instant Result</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus.</p>
        </div>
      </div>

      <div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.9s">
        <div class="feature-thumb">
          <div class="feature-icon">
            <span><i class="fa fa-bell-o"></i></span>
          </div>
           <h3>Many Quizs</h3>
           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elitquisque tempus ac eget diam et laoreet phasellus.</p>
        </div>
      </div>

    </div>
  </div>
</section>





<!-- Video section -->
<section id="video" class="parallax-section">
  <div class="overlay"></div>
    <div class="container">
      <div class="row">

          <div class="col-md-offset-2 col-md-8 col-sm-12">
             <!-- <a class="popup-youtube" href="https://www.youtube.com/watch?v=CRhCMl7ZI84"><i class="fa fa-play"></i></a>-->
              <h2 class="wow fadeInUp" data-wow-delay="0.5s">Watch the video</h2>
              <p class="wow fadeInUp" data-wow-delay="0.8s">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet. Dolore magna aliquam erat volutpat.</p>
          </div>

      </div>
    </div>
</section>



<section id="team" class="parallax-section">
  <div class="container">
    <div class="row">
      <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
         <div class="wow fadeInUp section-title" data-wow-delay="0.3s">
            <h2>Subjects</h2>
            <h4>Different kind of Quizs</h4>
        </div>
      </div>
      <div class="clearfix"></div>
      
      <?php
	  while($get_cat = $cat_sql->fetch_array()){
		  ?>
          <div class="col-md-3 col-sm-6 wow fadeInUp" data-wow-delay="0.4s">
           	 <div class="card card-block">
              <a href="category.php?cat_id=<?php echo $get_cat['category_id'];?>"><h3 class="card-title"><?php echo $get_cat['category'];?></h3></a>
             </div>
      	  </div>
          <?php
	  }
	  ?>
      
    </div>
  </div>
</section>



<!-- Contact section -->
<section id="contact" class="parallax-section">
  <div class="overlay"></div>
	<div class="container">
		<div class="row">

			<div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
            <div class="wow fadeInUp section-title" data-wow-delay="0.3s">
                <h2>Say hello</h2>
                <h4>we are always ready to serve you!</h4>
            </div>
				<div class="contact-form wow fadeInUp" data-wow-delay="0.7s">
                <?php if($msg != '') { echo "<p>".$msg."</p>"; } ?>
					<form id="contact-form" method="post" action="">
						<input name="name" type="text" class="form-control" placeholder="Your Name" required>
						<input name="email" type="email" class="form-control" placeholder="Your Email" required>
						<textarea name="message" class="form-control" placeholder="Message" rows="5" required></textarea>
						<input type="submit" name="contactmail" class="form-control submit" value="SEND MESSAGE">
					</form>
				</div>
			</div>
			
		</div>
	</div>
</section>

<?php require_once('include/footer.php');?>

<!-- javscript js -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.magnific-popup.min.js"></script>

<script src="js/jquery.backstretch.min.js"></script>

<script src="js/nivo-lightbox.min.js"></script>
<script src="js/jquery.parallax.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/wow.min.js"></script>

<script src="js/custom.js"></script>

</body>
</html>