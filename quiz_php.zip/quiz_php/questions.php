<!DOCTYPE html>
<html lang="en">
<head>
	
    <link  href="css/bootstrap.min.css" rel="stylesheet"/>
    <link href="css/prettify.css" rel="stylesheet">
  	
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">


<div class="preloader">
	<div class="sk-spinner sk-spinner-pulse"></div>
</div>



<!-- Navigation section -->
<div class="navbar navbar-default navbar-static-top" role="navigation">
  <div class="container">

    <div class="navbar-header">
      <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="icon icon-bar"></span>
        <span class="icon icon-bar"></span>
        <span class="icon icon-bar"></span>
      </button>
      <a href="#" class="navbar-brand">Quiz</a>
    </div>
    <div class="collapse navbar-collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php" class="smoothScroll">Home</a></li>
        <li><a href="Category.php" class="smoothScroll">Categories</a></li>
        <li><a href="#about" class="smoothScroll">About</a></li>
        <li><a href="#contact" class="smoothScroll">Contact</a></li>
      </ul>
    </div>

  </div>
</div>
  	
	<div class='container'>

			<section id="wizard">
			  <div class="page-header">
	            <h1>Wizard With Progress Bar using events</h1>
	          </div>

				<div id="rootwizard">
					<div class="navbar">
					  <div class="navbar-inner">
					    <div class="container">
                        <ul>
                            <li><a href="#tab1" data-toggle="tab">First</a></li>
                            <li><a href="#tab2" data-toggle="tab">Second</a></li>
                            <li><a href="#tab3" data-toggle="tab">Third</a></li>
                            <li><a href="#tab4" data-toggle="tab">Fourth</a></li>
                            <li><a href="#tab5" data-toggle="tab">Fifth</a></li>
                            <li><a href="#tab6" data-toggle="tab">Sixth</a></li>
                            <li><a href="#tab7" data-toggle="tab">Seventh</a></li>
                            <li><a href="#tab8" data-toggle="tab">Fifth</a></li>
                            <li><a href="#tab9" data-toggle="tab">Sixth</a></li>
                            <li><a href="#tab10" data-toggle="tab">Seventh</a></li>
                        </ul>
					 </div>
					  </div>
					</div>
                    <div id="bar" class="progress">
                      <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>
                    </div>
                    <style>
						.question{border:1px #ccc solid;padding:20px;}
						.col4{width:25%;float:left;}
					</style>
					<div class="tab-content">
					    <div class="tab-pane" id="tab1">
					      	<div class="question">
                            	<div class="question_title">fsgnsdflgbhskbgkdfsbgkfsdbgkjbgkjfdbgkjdfbgkjbgkjflksafla?</div>
                                <div class="question_ans row">
                                	<div class="col4">
                                    	<p>kjglbdfslkgbsdfkgbdfskgbdfsklgbdfslkjbgkdfsljbgkjdfs</p>
                                    </div>
                                    <div class="col4">
                                    	<p>kjglbdfslkgbsdfkgbdfskgbdfsklgbdfslkjbgkdfsljbgkjdfs</p>
                                    </div>
                                    <div class="col4">
                                    	<p>kjglbdfslkgbsdfkgbdfskgbdfsklgbdfslkjbgkdfsljbgkjdfs</p>
                                    </div>
                                    <div class="col4">
                                    	<p>kjglbdfslkgbsdfkgbdfskgbdfsklgbdfslkjbgkdfsljbgkjdfs</p>
                                    </div>
                                </div>
                            </div>
					    </div>
					    <div class="tab-pane" id="tab2">
					      2
					    </div>
						<div class="tab-pane" id="tab3">
							3
					    </div>
						<div class="tab-pane" id="tab4">
							4
					    </div>
						<div class="tab-pane" id="tab5">
							5
					    </div>
						<div class="tab-pane" id="tab6">
							6
					    </div>
						<div class="tab-pane" id="tab7">
							7
					    </div>
						<ul class="pager wizard">
							<li class="previous first" style="display:none;"><a href="#">First</a></li>
							<li class="previous"><a href="#">Previous</a></li>
							<li class="next last" style="display:none;"><a href="#">Last</a></li>
						  	<li class="next"><a href="#">Next</a></li>
						</ul>
					</div>
				</div>



			</section>
	</div>
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.bootstrap.wizard.js"></script>
	<script src="js/prettify.js"></script>
	<script>
	$(document).ready(function() {
	  	$('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
			var $total = navigation.find('li').length;
			var $current = index+1;
			var $percent = ($current/$total) * 100;
			$('#rootwizard .progress-bar').css({width:$percent+'%'});
		}});
		window.prettyPrint && prettyPrint()
	});
	</script>
</body>
</html>