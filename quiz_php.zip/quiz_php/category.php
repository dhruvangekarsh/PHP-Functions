<?php
	require_once('admin/include/config.php');
	
	$cat_sql = $con->query("SELECT * FROM subcategory ORDER BY category_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Steak House - Free HTML CSS Template</title>

  	<meta charset="utf-8">
	<link rel="stylesheet" href="css/bootstrap.min.css">
  	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
  	<link rel="stylesheet" href="css/nivo-lightbox.css">
  	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
  	<link rel="stylesheet" href="css/hover-min.css">
  	<link rel="stylesheet" href="css/flexslider.css">
	<link rel="stylesheet" href="css/style.css">
  	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
  	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600' rel='stylesheet' type='text/css'>
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">


<div class="preloader">
	<div class="sk-spinner sk-spinner-pulse"></div>
</div>

<?php require_once('include/nav.php'); ?>

<?php
if(isset($_REQUEST['cat_id'])){
	$recat_id = $_REQUEST['cat_id'];
	$request_cat = $con->query("SELECT * FROM subcategory WHERE category_id='$recat_id'");
	
	
?>
<section id="team" class="parallax-section">
  <div class="container">
    <div class="row">
      <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
         <div class="wow fadeInUp section-title" data-wow-delay="0.3s">
            <h2>Categories</h2>
            <h4>Different kind of Quizs</h4>
        </div>
      </div>
      <div class="clearfix"></div>
      
      <?php
	  
	  if($request_cat->num_rows > 0){
	  
	  while($get_recat = $request_cat->fetch_array()){
		  ?>
          <div class="col-md-3 col-sm-6 wow fadeInUp">
           	 <div class="card card-block" style="position:relative;">
              <a href="quiz.php?subcat_id=<?php echo $get_recat['sub_cat_id'];?>"><h3 class="card-title"><?php echo $get_recat['subcategory'];?></h3></a>
             </div>
      	  </div>
          <?php
	  }
	  
	  }
	else{
		echo "No Any Related Data Found";
	}
	  ?>
      
    </div>
  </div>
</section>
<?php
}
?>

<section id="team" class="parallax-section">
  <div class="container">
    <div class="row">
      <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
         <div class="wow fadeInUp section-title" data-wow-delay="0.3s">
            <h2>All Categories</h2>
            <h4>Different kind of Quizs</h4>
        </div>
      </div>
      <div class="clearfix"></div>
      
      <?php
	  while($get_cat = $cat_sql->fetch_array()){
		  ?>
          <div class="col-md-3 col-sm-6 wow fadeInUp" data-wow-delay="0.4s">
           	 <div class="card card-block" style="position:relative;">
             <a href="quiz.php?subcat_id=<?php echo $get_cat['sub_cat_id'];?>"><h3 class="card-title"><?php echo $get_cat['subcategory'];?></h3></a>
             </div>
      	  </div>
          <?php
	  }
	  ?>
      
    </div>
  </div>
</section>



<!-- Contact section -->
<section id="contact" class="parallax-section">
  <div class="overlay"></div>
	<div class="container">
		<div class="row">

			<div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
            <div class="wow fadeInUp section-title" data-wow-delay="0.3s">
                <h2>Say hello</h2>
                <h4>we are always ready to serve you!</h4>
            </div>
				<div class="contact-form wow fadeInUp" data-wow-delay="0.7s">
					<form id="contact-form" method="post" action="#">
						<input name="name" type="text" class="form-control" placeholder="Your Name" required>
						<input name="email" type="email" class="form-control" placeholder="Your Email" required>
						<textarea name="message" class="form-control" placeholder="Message" rows="5" required></textarea>
						<input type="submit" class="form-control submit" value="SEND MESSAGE">
					</form>
				</div>
			</div>
			
		</div>
	</div>
</section>

<?php require_once('include/footer.php');?>

<!-- javscript js -->
<script src="js/jquery.js" type="application/javascript"></script>
<script src="js/bootstrap.min.js" type="application/javascript"></script>

<script src="js/jquery.magnific-popup.min.js" type="application/javascript"></script>

<script src="js/jquery.sticky.js" type="application/javascript"></script>
<script src="js/jquery.backstretch.min.js" type="application/javascript"></script>

<script src="js/isotope.js" type="application/javascript"></script>
<script src="js/imagesloaded.min.js" type="application/javascript"></script>
<script src="js/nivo-lightbox.min.js" type="application/javascript"></script>

<script src="js/jquery.flexslider-min.js" type="application/javascript"></script>

<script src="js/jquery.parallax.js" type="application/javascript"></script>
<script src="js/smoothscroll.js" type="application/javascript"></script>
<script src="js/wow.min.js" type="application/javascript"></script>

<script src="js/custom.js" type="application/javascript"></script>

</body>
</html>